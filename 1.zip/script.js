// script.js

// Example functionality: Show an alert when the page loads
document.addEventListener("DOMContentLoaded", () => {
    console.log("Page loaded successfully!");
});


